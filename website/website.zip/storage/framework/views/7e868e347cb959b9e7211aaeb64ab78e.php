

<?php $__env->startSection('content'); ?>
<h1>About us</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sociomark-new-website\website\resources\views/Frontend/AboutUs.blade.php ENDPATH**/ ?>