<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <?php echo $__env->make('Frontend/partial/styleLinks', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <?php echo $__env->make('Frontend/partial/Header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('Frontend/partial/jsLinks', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html><?php /**PATH D:\xamppserver\htdocs\Sociomark-new\resources\views/Frontend/layout/app.blade.php ENDPATH**/ ?>