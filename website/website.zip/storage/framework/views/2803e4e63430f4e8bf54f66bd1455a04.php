<?php $__env->startSection('page-content'); ?>
<div class="page-content">

    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Tables</a></li>
            <li class="breadcrumb-item active" aria-current="page">Blog Table</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Blog Table</h6>
                    <!-- <p class="text-secondary mb-3">Read the <a href="https://datatables.net/" target="_blank"> Official DataTables Documentation </a>for a full list of instructions and other options.</p> -->
                    <div class="table-responsive">
                        <table id="dataTableExample" class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Blog Title</th>
                                    <th>Display On Home</th>
                                    <th>Status</th>
                                    <th>Category Id</th>
                                    <th>image</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($blog->id); ?></td>
                                    <td><?php echo e($blog->blog_name); ?></td>
                                    <td>
                                        <?php if($blog->display_on_home == 1): ?>
                                        <i data-feather="check" style="color: green;"></i>
                                        <?php else: ?>
                                        <i data-feather="x" style="color: red;"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($blog->status == 'active'): ?>
                                        <i data-feather="zap" style="color: grey;"></i>
                                        <?php else: ?>
                                        <i data-feather="zap-off" style="color: grey;"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(implode(', ', $blog->getCategoryNames()) ?: 'No Category'); ?></td>
                                    <!-- <td><?php echo e(implode(', ', $blog->getTagNames()) ?: 'No tag'); ?></td> -->
                                    <td>
                                        <?php if(!empty($blog->images) && is_array($blog->images)): ?>
                                        <?php $__currentLoopData = $blog->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(url('storage/app/public/' . $image)); ?>" width="50" height="50" style="object-fit: cover; margin-right: 5px;" alt="Blog Image">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        No Image
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($blog->created_at->format('Y-m-d')); ?></td>
                                    <td>
                                        <!-- Edit Icon -->
                                        <a href="<?php echo e(route('blogs.edit', $blog->id)); ?>" style="margin-right: 8px;">
                                            <i data-feather="edit"></i>
                                        </a>

                                        <!-- Delete Icon as a Form -->
                                        <form action="<?php echo e(route('blogs.destroy', $blog->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <a href="#" onclick="event.preventDefault(); if(confirm('Are you sure you want to delete this blog?')) this.closest('form').submit();">
                                                <i data-feather="trash-2" style="color: red;"></i>
                                            </a>
                                        </form>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sociomark-new-website\website\resources\views/Admin/Pages/Blog/Blogs.blade.php ENDPATH**/ ?>