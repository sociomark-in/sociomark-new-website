 <!-- Core JS -->
 <script src="<?php echo e(asset('admin-assets/vendors/core/core.js')); ?>"></script>

<!-- Plugin JS -->
<script src="<?php echo e(asset('admin-assets/vendors/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-assets/vendors/datatables.net/dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('admin-assets/vendors/datatables.net-bs5/dataTables.bootstrap5.js')); ?>"></script>

<!-- Feather Icons -->
<script src="<?php echo e(asset('admin-assets/vendors/feather-icons/feather.min.js')); ?>"></script>

<!-- App JS -->
<script src="<?php echo e(asset('admin-assets/js/app.js')); ?>"></script>

<!-- Custom JS for DataTables -->
<script src="<?php echo e(asset('admin-assets/js/data-table.js')); ?>"></script>

<!-- Custom js for this page -->
<script src="<?php echo e(asset('admin-assets/js/dashboard.js')); ?>"></script>
<!-- End custom js for this page --><?php /**PATH D:\xamppserver\htdocs\Sociomark-new\resources\views/admin/partials/jsLink.blade.php ENDPATH**/ ?>