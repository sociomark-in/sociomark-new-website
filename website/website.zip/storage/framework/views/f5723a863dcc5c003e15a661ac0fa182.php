<?php $__env->startSection('title', 'Contact'); ?>
<?php $__env->startSection('author', 'Your Company Name'); ?>
<?php $__env->startSection('description', 'This is a dynamic description for the home page.'); ?>
<?php $__env->startSection('keywords', 'seo, marketing, agency, web design'); ?>
<?php $__env->startSection('robots', 'INDEX,FOLLOW'); ?>

<style>
    #contact .contact-head {
        padding: 4rem 4rem 1rem 4rem;
    }

    #contact .head-text {
        font-size: 35px;
        line-height: 42px;
    }

    #contact .head-text-div {
        margin: 0px;
    }

    #contact .para-text {
        font-size: 17px;
        line-height: 24px;
    }

    #contact .contact-form input,
    #contact .contact-form textarea,
    #contact .contact-form select {
        border-radius: 10px;
    }

    #contact .contact-form .form-group {
        position: relative;
        margin-bottom: 2.5rem;
    }

    #contact .contact-form .form-group input,
    #contact .contact-form .form-group select,
    #contact .contact-form .form-group textarea {
        padding: 15px 10px 10px 15px;
    }

    #contact .contact-form .form-group label {
        position: absolute;
        top: 3px;
        left: 24px;
        font-weight: 500;
        font-size: 18px;
        transform: translateY(-50%);
        background-color: white;
        padding: 0px 12px;
        pointer-events: none;
        z-index: 2;
    }

    #contact .space-bottom {
        padding-bottom: 35px;
    }

    #contact .contact-form {
        background: transparent;
        border-radius: 10px;
        padding: 45px 23px;
        box-shadow: 0px 3px 11px -4px rgba(0, 0, 0, 0.59);
        -webkit-box-shadow: 0px 3px 11px -4px rgba(0, 0, 0, 0.59);
        -moz-box-shadow: 0px 3px 11px -4px rgba(0, 0, 0, 0.59);
    }

    #contact .space-bottom .form-head {
        font-size: 2rem;
        line-height: 2.5rem;
    }

    #contact .space-bottom .contact-media {
        border: none;
        padding: 20px;
    }

    #contact .contact-media .icon-btn {
        width: 46px;
        height: 46px;
        border-radius: 10px;
        background: transparent;
    }

    #contact .business-contact,
    #contact .careers-contact {
        font-size: 17px;
        margin-bottom: 2px;
        font-weight: 500;
    }

    #contact #map {
        margin: 0px 0px 2rem 0px;
    }

    @media only screen and (max-width: 600px) {
        #contact .contact-head {
            padding: 2rem 0.5rem;
        }

        #contact .head-text-div {
            margin-bottom: 13px;
        }

        #contact .head-mbl-text,
        #contact .space-bottom .head-mbl-text {
            font-size: 30px;
            line-height: 31px;
        }
    }

    .invalid-feedback {
        color: red;
        display: block;
    }
</style>
<?php $__env->startSection('content'); ?>
<main id="contact">
    <div class="breadcumb-wrapper " data-bg-src="<?php echo e(asset('frontend-assets/img/bg/breadcumb-bg.jpg')); ?>">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Contact Us</h1>
                <ul class="breadcumb-menu">
                    <li><a href="home-seo-agency.html">Home</a></li>
                    <li>Contact Us</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="overflow-hidden space contact-head">
        <div class="container">
            <div class="row">
                <div class="title-area text-center text-xl-start col-md-4 head-text-div">
                    <h2 class="sec-title head-text head-mbl-text">Don’t hesitate to contact us for any information.</h2>
                </div>
                <div class="text-center text-xl-start col-md-8">
                    <p class="para-text">We identify the most relevant and high-traffic keywords for your business. Our team conducts thorough research to understand.</p>
                    <p class="para-text">We identify the most relevant and high-traffic keywords for your business. Our team conducts thorough research to understand yourer.</p>
                </div>
            </div>
        </div>
        <hr>
    </div>


    <div class="space-bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <!-- <div class="title-area text-center">
                    </div> -->
                    <div class="row gy-4 flex-column">
                        <div class="col-xl-12 col-md-12">
                            <div class="contact-media">
                                <div class="icon-btn d-flex justify-content-center align-items-center">
                                    <i class="fa-sharp fa-light fa-location-dot"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="box-title">Our Address</h5>
                                    <p class="box-text">374 William S Canning Blvd, Fall River MA 2721, USA</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-12 col-md-12">
                            <div class="contact-media">
                                <div class="icon-btn d-flex justify-content-center align-items-center">
                                    <i class="fa-light fa-phone"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="box-title">Contact Number</h5>
                                    <h6 class="business-contact">For Business</h6>
                                    <p class="box-text">
                                        <a href="tel:+13217322978">Mobile: +13217322978</a>
                                        <a href="mailto:saorhelp@gmail.com">Email: saorhelp@gmail.com</a>
                                    </p>
                                    <h6 class="careers-contact">For Careers</h6>
                                    <p class="box-text">
                                        <a href="tel:+13217322978">Mobile: +13217322978</a>
                                        <a href="mailto:saorhelp@gmail.com">Email: saorhelp@gmail.com</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-12 col-md-12">
                            <div class="contact-media">
                                <div class="icon-btn d-flex justify-content-center align-items-center">
                                    <i class="fa-light fa-clock"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="box-title">Opening Hour</h5>
                                    <p class="box-text">Monday - Saturday: 9:00 - 18:00 Sunday: Closed</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 mt-sm-2">
                    <div class="">
                        <h3 class="text-center mb-15 form-head head-mbl-text">Please Fill In The Form Below</h3>
                        <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>


                        <form action="<?php echo e(route('contact.store')); ?>" method="POST" class="contact-form style2">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="name">Your Name</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name" placeholder="Enter your Name" value="<?php echo e(old('name')); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-md-6">
                                    <i class="far fa-envelope"></i>
                                    <label for="email">Email</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="email" placeholder="Enter your Email" value="<?php echo e(old('email')); ?>">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <i class="fal fa-phone"></i>
                                    <label for="phone">Phone</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" id="phone" placeholder="Enter your Phone" value="<?php echo e(old('phone')); ?>">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-md-6">

                                    <label for="service">Service you want?</label>
                                    <select class="form-select <?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="service" name="service">
                                        <option selected disabled>Choose an option</option>
                                        <option value="1">Option 1</option>
                                        <option value="2">Option 2</option>
                                        <option value="3">Option 3</option>
                                    </select>

                                    <?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-md-6">

                                    <label for="budget">Marketing Budget</label>
                                    <select class="form-select <?php $__errorArgs = ['budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="budget" name="budget">
                                        <option selected disabled>Choose an option</option>
                                        <option value="1">Option 1</option>
                                        <option value="2">Option 2</option>
                                        <option value="3">Option 3</option>
                                    </select>
                                    <?php $__errorArgs = ['budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-md-6">

                                    <label for="aboutUs">How did you hear about Us?</label>
                                    <select class="form-select <?php $__errorArgs = ['aboutUs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="aboutUs" name="aboutUs">
                                        <option selected disabled>Choose an option</option>
                                        <option value="1">Option 1</option>
                                        <option value="2">Option 2</option>
                                        <option value="3">Option 3</option>
                                    </select>
                                    <?php $__errorArgs = ['aboutUs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-12">

                                    <label for="messageforus">Your Message</label>
                                    <textarea class="form-control <?php $__errorArgs = ['messageforus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="messageforus" placeholder="Enter your message" rows="4" name="messageforus"></textarea>
                                    <i class="fal fa-pencil"></i>
                                    <?php $__errorArgs = ['messageforus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12 form-group mb-0 text-center">
                                    <button class="th-btn th-radius">Submit Message</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="map">
        <div class="container text-center">
            <div class="ratio ratio-16x9 " style="height: 450px;">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.8354345093706!2d-122.41941548468129!3d37.77492927975967!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8085809c5a2ff8fb%3A0xe4c2f0cfe65f3f3!2sSan%20Francisco%2C%20CA!5e0!3m2!1sen!2sus!4v1617843256256!5m2!1sen!2sus"
                    allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
    </div>


</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sociomark-new-website\website\resources\views/Frontend/ContactUs.blade.php ENDPATH**/ ?>