@extends('Frontend.layout.app')

@section('content')
<h1>About us</h1>
@endsection