 <!--==============================
    All Js File
============================== -->
    <!-- Jquery -->
    <script src="{{ asset('frontend-assets/js/vendor/jquery-3.7.1.min.js') }}"></script>
    <!-- Swiper Slider -->
    <script src="{{ asset('frontend-assets/js/swiper-bundle.min.js') }}"></script>
    <!-- Bootstrap -->
    <script src="{{ asset('frontend-assets/js/bootstrap.min.js') }}"></script>
    <!-- Magnific Popup -->
    <script src="{{ asset('frontend-assets/js/jquery.magnific-popup.min.js') }}"></script>
    <!-- Counter Up -->
    <script src="{{ asset('frontend-assets/js/jquery.counterup.min.js') }}"></script>
    <!-- Circle Progress -->
    <script src="{{ asset('frontend-assets/js/circle-progress.js') }}"></script>
    <!-- Range Slider -->
    <script src="{{ asset('frontend-assets/js/jquery-ui.min.js') }}"></script>
    <!-- Imagesloadedr -->
    <script src="{{ asset('frontend-assets/js/imagesloaded.pkgd.min.js') }}"></script>
    <!-- isotope -->
    <script src="{{ asset('frontend-assets/js/isotope.pkgd.min.js') }}"></script>
    <!-- Tilt.jquery -->
    <script src="{{ asset('frontend-assets/js/tilt.jquery.min.js') }}"></script>
    <!-- Nice-select -->
    <script src="{{ asset('frontend-assets/js/nice-select.min.js') }}"></script>
    <!-- wow -->
    <script src="{{ asset('frontend-assets/js/wow.min.js') }}"></script>
    <!-- Particles JS -->
    <script src="{{ asset('frontend-assets/js/particles.min.js') }}"></script>


    <script src="{{ asset('frontend-assets/js/particles-config.js') }}"></script>

    <!-- Gsap JS -->
    <script src="{{ asset('frontend-assets/js/gsap.min.js') }}"></script>
    <script src="{{ asset('frontend-assets/js/ScrollTrigger.min.js') }}"></script>
    <script src="{{ asset('frontend-assets/js/Splitetext.js') }}"></script>
    <script src="{{ asset('frontend-assets/js/lenis.min.js') }}"></script>

    <!-- imageRevealHover JS -->
    <script src="{{ asset('frontend-assets/js/imageRevealHover.js') }}"></script>

    <!-- Main Js File -->
    <script src="{{ asset('frontend-assets/js/main.js') }}"></script>