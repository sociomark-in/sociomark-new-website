'use strict';

(function () {

  if (document.querySelector('.perfect-scrollbar-example')) {
    var scrollbarExample = new PerfectScrollbar('.perfect-scrollbar-example');
  }

})();